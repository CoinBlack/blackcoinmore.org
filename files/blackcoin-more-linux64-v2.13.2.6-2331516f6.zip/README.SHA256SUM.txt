2020-07-21 Release

blackcoin-more-linux64-v2.13.2.6-2331516f6

Please check the sha256sum:

sha256sum blackmore*

cb47f2e12df0e4f5b2bbb69dae685cf1f37497ffb61a5cd03ea812caf4bee367  blackmore-cli
8e41c7d08d228f099dcb095e4db2fccaf390a15b63743ba944608440d4230a40  blackmore-qt
1f84d2f656d2b68772a63dd23c4d0348838e71bd23b376f13dc39a63b6602220  blackmore-tx
59ae7bd1677eb8d2d0e7d5f70735f023bd51e60ab888ad5e87db393f23050120  blackmored

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

Changelog:
- Fix staking memory leak (by JJ12880 from Radium Core)
- Updated fixed seeds
- Added secondary Blackcoin DNS seeder

For more info go to https://blackcoinmore.org/