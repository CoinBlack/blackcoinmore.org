blackcoin-more-macos-v13.2.0-699481612.zip (CLI,Deamon and QT Binaries)

sha256sum *

b4415a37a50f75312fdf7ad9b1493b9ed9668c16ce906ffc35dd2318eb0770d2  blackmore-cli
87cadb0bdf161c5edea4f7ba82343715317ee85b0c1646d2d595fc639ca6a04b  blackmore-qt
623a9587b831ac417dae080db20ab72c8823ee476bff6a3c3ecce928f735559e  blackmore-tx
a7b06579a54ac91be18122ff788dd7b67466d0b2379559a9c8a246bbf4701c73  blackmored

please visit https://blackcoinmore.org for more info

supported on MacOS 10.14 and higher (darwin18) 
