--------------------------------------------------------------------------------------------------
This is release v2.13.2.7-4ef44927. 

Changelog:

- Dust mitigation in mempool (by JJ12880 from Radium Core) 
- Compile on MacOS Catalina
- Cross-compile MacOS with Xcode 11.3.1
- Updated dependencies for Windows x64, Linux x64, MacOS, ARM64, ARMv7
- Sign/verify compatibility with legacy clients 
- Increased dbcache to 450MB
- Disabled stake cache for now
- Updated fixed seeds for mainnet and testnet

This release will mitigate a dust attack, when all nodes on the Blackcoin network run this version.

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the MacOS binaries:

07817ad52b0dfb56ddcb13aad0db0ef5d85dcf11e9ed781716dc6e1d91d6f672  blackmore-cli.exe
dc192ff48d5b3b6cb3e46dde7d0c01fddb4077ed7de530b9bc69f4bcc1a07614  blackmore-qt.exe
9f0038057a4580b57e9fb097237f00b1a047f71c869f30929400f786814324e4  blackmore-tx.exe
aa9d90c9d1d4bcc1c8a0d4f06d1731d88e228ce2836d33acb103e1e91c79dca2  blackmored.exe

The binaries are cross-compiled on Ubuntu 18.04
source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------