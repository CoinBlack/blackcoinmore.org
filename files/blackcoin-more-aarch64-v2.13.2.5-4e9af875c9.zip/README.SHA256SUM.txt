blackcoin-more-aarch64-v2.13.2.5-4e9af875c9

sha256sum blackmore*
46fb4d4b928237854174c08b9a6407a20fc47f0927ec1cc936e4958b0a66c8e1  blackmore-cli
6defde982902f4d5ea8d11dce4782a8001df73c238110e2809dee29926dbc0cb  blackmore-qt
f341ae3b468960ad05bf8e930e381924807cb7281debfbae4627379a608cb020  blackmore-tx
174f400e4977a120f92e60543293609b3d87cd1ab30a5607159a618a7989b878  blackmored

This version solves the "missing utxo" issue. The Berkeley Database has been upgraded to version 6.2.38 

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Updated Berkeley DB to 6.2.38
- Updated OpenSSL to 1.0.2u
- Updated fixed seeds
- Changed default port on regtest to 35714

For more info go to https://blackcoinmore.org/
