2020-07-21 Release

blackcoin-more-armv7-v2.13.2.6-2331516f6

Please check the sha256sum:

sha256sum blackmore*

e1365a756a0d3dcd30391f49167187b036501e74df620865136c853f07b01a81  blackmore-cli
b07fa2c251e10087d56a1a5a861ca23a436e505047711d34d432efd9f6d73961  blackmore-qt
670fd1053de5693f5ee73da66792aed81b7b588a937d8926f37fe855c880838c  blackmore-tx
afe0ac8146d0f7255863ec55d864828eec84fdcfa1c6e7c8816521cc06bc1ee6  blackmored

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

Changelog:
- Fix staking memory leak (by JJ12880 from Radium Core)
- Updated fixed seeds
- Added secondary Blackcoin DNS seeder

For more info go to https://blackcoinmore.org/


