--------------------------------------------------------------------------------------------------
This is release v2.13.2.7-4ef44927. 

Changelog:

- Dust mitigation in mempool (by JJ12880 from Radium Core) 
- Compile on MacOS Catalina
- Cross-compile MacOS with Xcode 11.3.1
- Updated dependencies for Windows x64, Linux x64, MacOS, ARM64, ARMv7
- Sign/verify compatibility with legacy clients 
- Increased dbcache to 450MB
- Disabled stake cache for now
- Updated fixed seeds for mainnet and testnet

This release will mitigate a dust attack, when all nodes on the Blackcoin network run this version.

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the Linux64 binaries:

03aa561a464e9d3d95d4ed7e5cf6544dec7e716221f8f78758032b8b3665d73c  blackmore-cli
e9c37db7ec80d6bb8cafebb173414911665a9e098fb8fd7462eee8270e56bf5d  blackmore-qt
63626adb2482c75003c46be5de06f03d3b25289c62d337568a276724b3d96a2c  blackmore-tx
a8fd2b696d0d819b13ccfac61686eea8a0638e67df3e3e869fbc95507d22b6ec  blackmored

The binaries are cross-compiled on Ubuntu 18.04
source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
