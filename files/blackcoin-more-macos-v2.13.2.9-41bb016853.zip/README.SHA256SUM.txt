blackcoin-more-macos-v2.13.2.9-41bb016853.zip (CLI,Deamon and QT Binaries)

sha256sum *
052eb2f6e1570b37c79b43bdb6cbbda6c7f8fd3adbdd09329d39d4c1c5dea267  blackmore-cli
8dec87a9d40821f635a62dcd82fcbe6af0be99460cb42807941901f813883621  blackmored
8fba6cf95c4b29f9104495a07c21b77d2a9fa10b21754a3136698c475448f5a3  blackmore-qt
fc3d0af726960b57f55203da37943755b8e0964a09965e9b2b398a64ad4480b9  blackmore-tx

please visit https://blackcoinmore.org for more info

support on DARWIN18 - MacOS 10.14 and higher 
