2020-07-21 Release

blackcoin-more-aarch64-v2.13.2.6-2331516f6

Please check the sha256sum:

sha256sum blackmore*

edd963b2e992cbfebda84d22650a59981f67d53057e0da9c005451e17e41aa0c  blackmore-cli
33898d4fa122c096b9ac132d633bda4092d92e3539c3939f87628f3dd1634bfc  blackmore-qt
7109333a48b025c08e13d2ed8b4876dcfde4c1f391d06fc15aff4652981c9899  blackmore-tx
76ed63173293726eda9d3d9bcb819f128855e90f15e80c68dfcc5614a9f6c6a3  blackmored

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

Changelog:
- Fix staking memory leak (by JJ12880 from Radium Core)
- Updated fixed seeds
- Added secondary Blackcoin DNS seeder

For more info go to https://blackcoinmore.org/
