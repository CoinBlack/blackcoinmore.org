--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for Linux64 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the Linux64 binaries:

590c826ddd415a2e70a8f03f0dd91002a914778bae519f7dceba36a6c347eb66  blackmore-cli
74ad71c0e6ec08f164f103f35bf9e0e26c8a5c1b33b024bed2ed5cffaaa242d0  blackmored
98254e3c7362339e3150aac1ad2f5c99907498a7ec8266e25750c93665aa6846  blackmore-qt
807e6294b16d5c19a5d01041c1a9153966afff7ebfdb1c98e7ea7f8b51d9902f  blackmore-tx
The binaries are (cross)compiled from the dependencies, on Ubuntu 18.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
