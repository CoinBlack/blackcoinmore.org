--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for Linux64 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the Linux64 binaries:

5546150ee6afafe7b2a2818f0fbc6a0b05f8eab5d6a8bfc61b96aed9e24cef74  blackmore-cli
09b94d6fae69b9194df5eb55ac77c53b0c3b52746c8cbd55307b8aaea7a4e3e0  blackmored
30f07f2faed4dd77c27e4e5ba53717bcb610ed8bd3dda35d06334413fbdb240a  blackmore-qt
810039b8000e0a8a513d2cb5dcefc546d157271c95241fd3c3c95a0810018077  blackmore-tx

The binaries are (cross)compiled from the dependencies, on Ubuntu 20.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
