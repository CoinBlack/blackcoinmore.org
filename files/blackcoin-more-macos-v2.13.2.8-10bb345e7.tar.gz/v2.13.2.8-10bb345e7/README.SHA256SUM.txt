--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for MacOS 10.13+ (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the MacOS binaries:

357f5eb0d49532d0fa564b011d12c0cf09d140a05f0a771e5de0e0eb425a04ba  blackmore-cli
9c47d2fcacbf3615e4cbd50e153c3d8264319b33301118802861659c9762fbee  blackmore-qt
aa022f92e947364900f2d42e4e17fa14298d0149a02f7b75c89360355201ed47  blackmore-tx
b46c5b9f89dfe3558543f3764c5fc2fa4b20f1db34bbeda395b89f923fdcd7e7  blackmored

SHA256SUM for the Blackmore-Qt.dmg

c5f6818a7f946bcc30c51c0bc606cca5ae03a5c8361ddef342c042005e29cbbc  Blackmore-Qt.dmg

The binaries are compiled from the dependencies, on Ubuntu Catalina 10.15.7 

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
