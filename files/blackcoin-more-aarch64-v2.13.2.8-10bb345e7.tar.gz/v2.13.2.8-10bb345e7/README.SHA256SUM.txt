--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for AArch64/amd64 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the AArch64/amd64 binaries:

0cc1714a20ee1cd73610a773c3d5c886e70bb044f4258eb1e0391706647a4cef  blackmore-cli
40ad2b5a4c34bbabb6b737a17df001c6947a845a661519d209150dc003eb7522  blackmored
dc8c7a9495b0fba878a6d2521755e30e767c2a491dd4a3ad319aacff2abd96f0  blackmore-qt
ff19363d62f12efa13ee43bcba608416c97150c47dc58059a6de0546c997be00  blackmore-tx

The binaries are (cross)compiled from the dependencies, on Ubuntu 20.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
