--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for AArch64/amd64 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the AArch64/amd64 binaries:

e8c17937175bdac0c3337532c44d0cdad91f9e5c94a2143c54e40fe4b0e5e50b  blackmore-cli
cd21da04aa8cdd6817855650b81e2584aa94c3f5a704d4f755f992b9e82f80f0  blackmored
be8e9276e3791346e79c086b9f4077e72f9c67d8c348acda20a75d1c416ac8fc  blackmore-qt
1f7575114bf0893940f636130fc4d9ccacd989c89f306859fefeb81a4eb19cde  blackmore-tx

The binaries are (cross)compiled from the dependencies, on Ubuntu 18.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
