---------------------------------------------------------------------------------------------------
This is release v2.13.2.7-4ef44927. 

Changelog:

- Dust mitigation in mempool (by JJ12880 from Radium Core) 
- Compile on MacOS Catalina
- Cross-compile MacOS with Xcode 11.3.1
- Updated dependencies for Windows x64, Linux x64, MacOS, ARM64, ARMv7
- Sign/verify compatibility with legacy clients 
- Increased dbcache to 450MB
- Disabled stake cache for now
- Updated fixed seeds for mainnet and testnet

This release will mitigate a dust attack, when all nodes on the Blackcoin network run this version.

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the Aarch64(arm64) binaries:

a8dc8774e245d65a2e887f15e48a7bbaadeb955c6fcebc32423c0ca782ff8c13  blackmore-cli
5b836098b128245873e0a88482987a5188988e72513a368979c7866a385038ca  blackmore-qt
0f30083265ba5b1d9cc3144852dab8fc057c22dcfa6ab1eb1976b4105bd656cb  blackmore-tx
7fd23a6662042f42acddfe107c7dc9c46406e3155a0070706ffc26d06f302966  blackmored

The binaries are cross-compiled on Ubuntu 18.04
source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
