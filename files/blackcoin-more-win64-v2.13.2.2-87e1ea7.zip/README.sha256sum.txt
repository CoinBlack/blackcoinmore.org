~/Blackmore/v2.13.2.2-87e1ea7/Win64$ sha256sum *

adad598d792ad1a93e5db9ab37fe19629453db2a486fff828bcf4683c9270acb  blackmore-cli.exe
0c4e91be504df487241099a96fbb815f0362387c166763e3f7dcbd5ee8fc8ec8  blackmored.exe
479f3e40edbb95cde5b7a69a839fae47bd9c410bf7ae90a7a0ee10c0624ffa3d  blackmore-qt.exe
630e40a2569ad1b7f2bf20076f8903d52316043c2f8350dac8c235b1e93267d8  blackmore-tx.exe

Please visit https://www.blackcoinmore.org/

