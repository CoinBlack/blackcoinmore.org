---------------------------------------------------------------------------------------------------
This is release v2.13.2.7-4ef44927. 

Changelog:

- Dust mitigation in mempool (by JJ12880 from Radium Core) 
- Compile on MacOS Catalina
- Cross-compile MacOS with Xcode 11.3.1
- Updated dependencies for Windows x64, Linux x64, MacOS, ARM64, ARMv7
- Sign/verify compatibility with legacy clients 
- Increased dbcache to 450MB
- Disabled stake cache for now
- Updated fixed seeds for mainnet and testnet

This release will mitigate a dust attack, when all nodes on the Blackcoin network run this version.

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the ARMv7 binaries:

a40e790517f064e6be9862ac2bcff9fb5bd7d926a72dc6322a5ffda74cc0b510  blackmore-cli
d771b2827cb138b05dfc3ea7c14b6792150b1c2b6deff8a0d0d3617baf8cc9fd  blackmore-qt
45541763557302012fb0c862df47ca20e3d83f5fcb54e45edbaa438faa293060  blackmore-tx
5c7880a6175e58f6a86e9b43eae72156b24627cc260dfea47511193aaaa041e3  blackmored

The binaries are cross-compiled on Ubuntu 18.04
source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
