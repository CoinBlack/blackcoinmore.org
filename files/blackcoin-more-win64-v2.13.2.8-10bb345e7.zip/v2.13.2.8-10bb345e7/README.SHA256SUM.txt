--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for Win64 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the Win64 binaries:

2fa439d8a34c1e2ff5c4e6733859d61a0c797a044baa914ca94a16eab56035bd  blackmore-cli.exe
bb8b6aec001cb145ce7a2cd75f3317d225f67684c66f4c638809b5ab0f6f5afd  blackmored.exe
5de83a259ba0c90eae5e8348f0185c4194902bca4e5a2eed28dcd919163aee41  blackmore-qt.exe
f29b64fcb2e6b479e92636bd0762177b279412d92c6297a007865a66695d5648  blackmore-tx.exe

The binaries are (cross)compiled from the dependencies, on Ubuntu 20.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
