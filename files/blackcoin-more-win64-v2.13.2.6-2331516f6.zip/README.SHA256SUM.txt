2020-07-21 Release

blackcoin-more-win64-v2.13.2.6-2331516f6

Please check the sha256sum:

sha256sum blackmore*

213b3de4afa5948aefa6582371e843fda0a8221222d77dfe7b84440ade838bf7  blackmore-cli.exe
873b622e6ce3c084b1c7801d01e3a6a1f0c4db32e7e6c9a7f068b796c099acd0  blackmore-qt.exe
ae0601a93828dabf540791c0f78db75c00b12dbf9db7b613b090d26bfe8a8e65  blackmore-tx.exe
b5d35893950fb5a9e9185a0bda3cef5f9017baecb96553509184be39beba13ea  blackmored.exe

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

- Fix staking memory leak (by JJ12880 from Radium Core)
- Updated fixed seeds
- Added secondary Blackcoin DNS seeder

For more info go to https://blackcoinmore.org/