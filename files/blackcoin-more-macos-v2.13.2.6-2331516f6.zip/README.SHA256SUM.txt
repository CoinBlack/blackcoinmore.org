2020-07-21 Release

blackcoin-more-macos-v2.13.2.6-2331516f6

Please check the sha256sum:

sha256sum blackmore*

463fe48de4dd8d3550748a2df608aa4a5746511935c4f8808a5d2fd8ea55ef7a  blackmore-cli
ed391a10acf449579dc8c2d2e576e50162ef862c7e417af33e77f670085286cb  blackmore-qt
a701a6bb365e7f34dc5807ecc47abb4e1ef52a2a564260b322e77e954235d27e  blackmore-tx
fc312a224f0a470bdfd4a4b359a1c82630f85fac243a395f5798fa596eb71946  blackmored

PLEASE BACKUP YOUR WALLET BEFORE UPGRADING! (Wallet.dat) 

Changelog:
- Fix staking memory leak (by JJ12880 from Radium Core)
- Updated fixed seeds
- Added secondary Blackcoin DNS seeder

For more info go to https://blackcoinmore.org/