--------------------------------------------------------------------------------------------------
This is release v2.13.2.7-4ef44927. 

Changelog:

- Dust mitigation in mempool (by JJ12880 from Radium Core) 
- Compile on MacOS Catalina
- Cross-compile MacOS with Xcode 11.3.1
- Updated dependencies for Windows x64, Linux x64, MacOS, ARM64, ARMv7
- Sign/verify compatibility with legacy clients 
- Increased dbcache to 450MB
- Disabled stake cache for now
- Updated fixed seeds for mainnet and testnet

This release will mitigate a dust attack, when all nodes on the Blackcoin network run this version.

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the MacOS binaries:

Disk Image Installer:
3f7b1f8ce31eedb5f56368341c975e907ca1562d0c72fc1d3506543a09ae2b0c  blackcoin-more-macos-v2.13.2.7-4ef44927a.dmg

Standalone Binaries:
272a6b59030d676a8df99f2a3f1374b750ba8abc6bb668e2d08aadc2d5cba3aa  blackmore-cli
adb02afe0722ad2221188d31b35bc1deee494fc6d48b4d7bfd9257db3908ee62  blackmore-qt
57de61e6e1e76abff7113987f88d41af5b28d41518d286c16f83f79209681f72  blackmore-tx
bd3419e03d1146be19c97409ae6a9ab0399dfd5c5a3a543306659b5d9b0e4b0b  blackmored

The binaries are cross-compiled on Ubuntu 18.04
source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
