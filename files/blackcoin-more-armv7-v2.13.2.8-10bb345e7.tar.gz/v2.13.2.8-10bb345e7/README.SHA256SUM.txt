--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for ARMv7 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the ARMv7 binaries:

fc1dd6dd95642b172a82311a861df1656fd4a30d36d46398d7602d4f2fd0f238  blackmore-cli
18d6f0e7bf2326ee85a6795f70882f9227b14e39f3d085d291a274f3896b1bc0  blackmored
85b63b5db7bc61e87dc6bcb90b0ff0fc8b0ca9a90c0b6a0a79b6a592ddd456c3  blackmore-qt
6947879c5050c6eaa216c34b3bf6f890daef74f3be91815b7a8f506ed160228d  blackmore-tx

The binaries are (cross)compiled from the dependencies, on Ubuntu 20.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
