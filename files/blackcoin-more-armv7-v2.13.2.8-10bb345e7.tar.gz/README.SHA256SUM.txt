--------------------------------------------------------------------------------------------------
This is release v2.13.2.8-10bb345e7 for ARMv7 (2021-02-24) 

Changelog:

- Immediately ban clients operating on forked chains older than nMaxReorganizationDepth
- Fixed IsDust() policy to allow atomic swaps
- Updated fixed seeds for mainnet and testnet
- Updated dependencies for MacOS

For more info visit https://blackcoinmore.org/ or come to Discord https://discord.gg/hjNUgWD

---------------------------------------------------------------------------------------------------

SHA256SUM for the ARMv7 binaries:

edc720e6aa4d21daa66a12a68242f3caa4bdac6baec8219eab9962a62781d276  blackmore-cli
7b6a09746fa9ee4406150599b32f21defa50fcf02cceca6a4d6cc4c3a4148f66  blackmored
e0799656486701c16a45e339e01853cc00737ccbd9ff9fe66861b38a765ed0f6  blackmore-qt
9f6d5eb6b90ec844df3eb4a76d03067c62835cc1103bb9f4adbd163eaed703be  blackmore-tx

The binaries are (cross)compiled from the dependencies, on Ubuntu 18.04

source: https://gitlab.com/blackcoin/blackcoin-more
--------------------------------------------------------------------------------------------------
